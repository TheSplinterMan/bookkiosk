/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import utils.MySQLConnection;

/**
 *
 * @author PC-Denzell
 */
public class Student extends UnivMember {

    private static Iterable<Student> studentDB;
    //Variables
    ArrayList<Book> studentInventory = new ArrayList<>();

    public Student(int id, String Fname, String Lname, String password, boolean isStaff) {
        super(id, Fname, Lname, password, false);
    }

    public ArrayList<Book> getStudentInventory() {
        return studentInventory;
    }

    public String getFullName() {

        return (Fname + " " + Lname);
    }

    public int getID() {
        return id;
    }

    public static Student findStudent(int id){
        for (Student stud : studentDB) {
            if (stud.getId() == id) {
                return stud; //gotcha!
            }
        }
        return null; // Student not found.
    }
    
    public boolean login(){
        boolean validated = false;
        
        /**
        * Scanning the database for entered student ID to see if it exists.
        * If it matches a valid ID, find the password and compare to entered
             * password.
             */
            
        try {
            Connection conn = MySQLConnection.getConnection();
            String sql = "select * from univmember where id = ? and password = ?";
            PreparedStatement stmt = conn.prepareCall(sql);
            stmt.setInt(1, id);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
                if (rs.next()){
                    validated = true;
                }
        } catch (Exception exp) {
            exp.printStackTrace();
        } finally {
            MySQLConnection.closeConnection();
        }
        
        return validated;
    }
}
