/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author PC-Denzell
 */
class LibraryStaff extends UnivMember {

    public LibraryStaff(int id, String Fname, String Lname, String password, boolean isStaff) {
        super(id, Fname, Lname, password, true);
    }
}