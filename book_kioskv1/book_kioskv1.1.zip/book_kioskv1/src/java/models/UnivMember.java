/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.io.Serializable;

/**
 *
 * @author PC-Denzell
 */
public class UnivMember implements Serializable {
    //Variables
    int id;
    String Fname;
    String Lname;
    String password;
    boolean isStaff;

    //Constructor for Univ Member
    public UnivMember(int id, String Fname, String Lname, String password, boolean isStaff){
        this.id = id;
        this.Fname = Fname;
        this.Lname = Lname;
        this.password = password;
        this.isStaff = isStaff;
    }

    //Getters for each variable
    public int getId() {
        return id;
    }

    public String getFname() {
        return Fname;
    }

    public String getLname() {
        return Lname;
    }

    public String getPassword() {
        return password;
    }

    public boolean isStaff() {
        return isStaff;
    }

    //Setters for each variable
    public void setId(int id) {
        this.id = id;
    }

    public void setFname(String fname) {
        Fname = fname;
    }

    public void setLname(String lname) {
        Lname = lname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setStaff(boolean staff) {
        isStaff = staff;
    }
}
