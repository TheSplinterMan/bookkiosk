/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author PC-Denzell
 */
public class Book {
    //Variables
    String bookTitle;
    int BookID;
    String Author;
    String ISNnum;
    String category;
    int checkedOutBy;
    int reservedBy;

    public Book(String bookTitle, int BookID, String Author, String ISNnum, String category, int checkedOutBy,int reservedBy){
        this.bookTitle = bookTitle;
        this.BookID = BookID;
        this.Author = Author;
        this.ISNnum = ISNnum;
        this.category = category;
        this.checkedOutBy = checkedOutBy;
        this.reservedBy = reservedBy;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public int getBookID() {
        return BookID;
    }

    public String getAuthor() {
        return Author;
    }

    public String getCategory() {
        return category;
    }

    public String getISNnum() {
        return ISNnum;
    }

    public int getCheckedOutBy() {
        return checkedOutBy;
    }

    public int getReservedBy() {
        return reservedBy;
    }
}
